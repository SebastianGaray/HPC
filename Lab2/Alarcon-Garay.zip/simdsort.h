#include "heap.h"
void simdsort(int debugFlag, float *data);