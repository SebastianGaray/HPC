
void readFile(char *inputFile, int N, float *array);
void writeFile(char *outputFile, int N, float *outputArrayFinal);